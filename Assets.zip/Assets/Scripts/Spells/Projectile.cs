public class ProjectileData
{
    public string Trajectory;
    public string SpeedExpr;
    public string LifetimeExpr;
    public int Sprite;
}
